import SwiftUI

@main
struct Henshin15App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
